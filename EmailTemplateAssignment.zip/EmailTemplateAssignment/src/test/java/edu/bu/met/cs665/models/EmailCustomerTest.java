package edu.bu.met.cs665.models;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class EmailCustomerTest {

    // Setup new output stream.
    private final ByteArrayOutputStream outStream = new ByteArrayOutputStream();
    // Save initial print stream being used.
    private final PrintStream initOut = System.out;

    private BusinessEmail businessEmail;
    private ReturningEmail returningEmail;
    private FrequentEmail freqEmail;
    private NewEmail newEmail;
    private VipEmail vipEmail;

    private final String customer = "Cathrine";
    private final String employee = "Peter Gilbert";

    @Before
    public void setUp() throws Exception {
        // Set new stream to standard output.
        // Used to read print statements in tests.
        System.setOut(new PrintStream(outStream));

        businessEmail = new BusinessEmail();
        freqEmail = new FrequentEmail();
        returningEmail = new ReturningEmail();
        newEmail = new NewEmail();
        vipEmail = new VipEmail();
    }

    @Test
    public void testGenerateEmail_BusinessEmail() {

        String expectedEmail = "The Nike Shoes Shop - Personalized Shoes ALL!\n"
                + "Business Account Renewal\n"
                + "Greetings Cathrine,\n"
                + "We are contacting you to notify you that your business account is due for renewal within 30 days from now.\n"
                + "If no payments are received by the end of this period your business account will be deactivated.\n"
                + "Thanks for your support,\n"
                + "Peter Gilbert\n"
                + "Team Member @ The Nike Corporation\n";

        businessEmail.generateEmail(customer, employee);

        assertEquals(expectedEmail, outStream.toString());
    }


    @Test
    public void testWrongGenerateEmail_BusinessEmail() {

        String expectedEmail = "The Nike Shoes Shop - Personalized Shoes ALL!\n"
                + "Business Account Renewal\n"
                + "Greetings Cathrine,\n"
                + "Thanks for your support,\n"
                + "Peter Gilbert\n"
                + "Team Member @ The Nike Corporation\n";

        businessEmail.generateEmail(customer, employee);

        assertNotEquals(expectedEmail, outStream.toString());
    }

    @Test
    public void testGenerateEmail_FrequentEmail() {

        freqEmail.generateEmail(customer, employee);

        String expectedEmail = "The Nike Shoes Shop - Personalized Shoes ALL!\n"
                + "Special Offer!!!\n"
                + "Greetings Cathrine,\n"
                + "Hope you are having a lovely day! :)\n"
                + "Thank you for being a loyal customer!\n"
                + "For a limited time save 40% your account renewal with promo code: \n"
                + "SHOE2023NX\n"
                + "Sincerely,\n"
                + "Peter Gilbert\n"
                + "Team Member @ The Nike Corporation\n";
        assertEquals(expectedEmail, outStream.toString());
    }
    @Test
    public void testWrongGenerateEmail_FrequentEmail() {

        freqEmail.generateEmail(customer, employee);

        String expectedEmail = "The Nike Shoes Shop - Personalized Shoes ALL!\n"
                + "Special Offer!!!\n"
                + "Greetings Cathrine,\n"
                + "Hope you are having a lovely day! :)\n"
                + "Thank you for being a loyal customer!\n"
                + "For a limited time save 40% your account renewal with promo code: \n"

                + "Sincerely,\n"
                + "Peter Gilbert\n"
                + "Team Member @ The Nike Corporation\n";
        assertNotEquals(expectedEmail, outStream.toString());
    }

    @Test
    public void testGenerateEmail_ReturningEmail() {

        returningEmail.generateEmail(customer, employee);

        String expectedEmail = "The Nike Shoes Shop - Personalized Shoes ALL!\n"
                + "Welcome Back!\n"
                + "Greetings Cathrine,\n"
                + "It has been a while since you last logged in.\n"
                + "Make sure to checkout our recent newsletter for up-to-date information on new rubber ducks in stock!\n"
                + "Sincerely,\n"
                + "Peter Gilbert\n"
                + "Team Member @ The Nike Corporation\n";

        assertEquals(expectedEmail, outStream.toString());
    }

    @Test
    public void testWrongGenerateEmail_ReturningEmail() {

        returningEmail.generateEmail(customer, employee);

        String expectedEmail = "The Nike Shoes Shop - Personalized Shoes ALL!\n"
                + "Welcome Back!\n"
                + "Greetings Cathrine,\n"
                + "It has been a while since you last logged in.\n"
                + "Make sure to checkout our recent newsletter for up-to-date information on new rubber ducks in stock!\n"
                + "Sincerely,\n"
                + "Peter Gilbert\n"
                + "Team Member @ The Nike Corporation\n";

        assertEquals(expectedEmail, outStream.toString());
    }

    @Test
    public void testGenerateEmail_NewEmail() {

        newEmail.generateEmail(customer, employee);

        String expectedEmail = "The Nike Shoes Shop - Personalized Shoes ALL!\n"
                + "Welcome to The Rubber Duck Shop!\n"
                + "Greetings Cathrine,\n"
                + "We are glad to have you onboard!\n"
                + "You should receive another email containing the confirmation link for your account.\n"
                + "Please be sure to verify your account by clicking that link, and feel free to reach out\n"
                + "if you have any other questions!\n"
                + "Sincerely,\n"
                + "Peter Gilbert\n"
                + "Team Member @ The Nike Corporation\n";

        assertEquals(expectedEmail, outStream.toString());
    }

    @Test
    public void testWrongGenerateEmail_NewEmail() {

        newEmail.generateEmail(customer, employee);

        String expectedEmail = "The Nike Shoes Shop - Personalized Shoes ALL!\n"
                + "Welcome to The Rubber Duck Shop!\n"
                + "Greetings Cathrine,\n"
                + "We are glad to have you onboard!\n"
                + "You should receive another email containing the confirmation link for your account.\n"

                + "Sincerely,\n"
                + "Peter Gilbert\n"
                + "Team Member @ The Nike Corporation\n";

        assertNotEquals(expectedEmail, outStream.toString());
    }

    @Test
    public void testGenerateEmail_VipEmail() {

        vipEmail.generateEmail(customer, employee);

        String expectedEmail = "The Nike Shoes Shop - Personalized Shoes ALL!\n"
                + "VIP Monthly Update\n"
                + "Greetings Cathrine,\n"
                + "This is our monthly update email to keep you informed on all the up-to-date news: \n"
                + "-> Taylor Swift New Merch is Available exclusive to VIP members\n"
                + "-> Get Hands on it before anyone else with 20% discount! View your account portal on our website for more info!\n"
                + "Now here is your monthly VIP perk!\n"
                + "Use the code below to get 75% off your next purchase:\n"
                + "NIKE6645EGS\n"
                + "Sincerely,\n"
                + "Peter Gilbert\n"
                + "Team Member @ The Nike Corporation\n";

        assertEquals(expectedEmail,outStream.toString());
    }

    @Test
    public void testWrongGenerateEmail_VipEmail() {

        vipEmail.generateEmail(customer, employee);

        String expectedEmail = "The Nike Shoes Shop - Personalized Shoes ALL!\n"
                + "VIP Monthly Update\n"
                + "Greetings Cathrine,\n"
                + "This is our monthly update email to keep you informed on all the up-to-date news: \n"
                + "-> Taylor Swift New Merch is Available exclusive to VIP members\n"
                + "-> Get Hands on it before anyone else with 20% discount! View your account portal on our website for more info!\n"
                + "Now here is your monthly VIP perk!\n"
                + "Use the code below to get 75% off your next rubber duck purchase:\n"

                + "Sincerely,\n"
                + "Elena Gilbert\n"
                + "Team Member @ The Nike Corporation\n";

        assertNotEquals(expectedEmail,outStream.toString());
    }

    @After
    public void resetStreams() {
        // Returns output stream to initial state before testing.
        System.setOut(initOut);
    }
}
