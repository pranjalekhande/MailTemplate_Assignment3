/**
 * Name: Pranjal Prasanna Ekhande
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: VipEmail.java
 * Description: Overrides CustomerEmail to crafting professional sale for VIP customer.
 */

package edu.bu.met.cs665.models;

public class VipEmail extends CustomerEmail {

    public VipEmail() {
        super(CustomerType.VIP);
    }

    @Override
    public void doSubjectLine() {
        System.out.println("VIP Monthly Update");
    }

    @Override
    public void doMessage() {
        System.out.println("This is our monthly update email to keep you informed on all the up-to-date news: ");
        System.out.println("-> Taylor Swift New Merch is Available exclusive to VIP members");
        System.out.println("-> Get Hands on it before anyone else with 20% discount! View your account portal on our website for more info!");
    }

    @Override
    public void doPromotion() {
        System.out.println("Now here is your monthly VIP perk!");
        System.out.println("Use the code below to get 75% off your next purchase:");
        System.out.println("NIKE6645EGS");
    }
}
