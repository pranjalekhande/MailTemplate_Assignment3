/**
 * Name: Pranjal Prasanna Ekhande
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: ReturningEmail.java
 * Description: Overrides CustomerEmail to crafting returning user message after login.
 */
package edu.bu.met.cs665.models;

public class ReturningEmail extends CustomerEmail {

    public ReturningEmail() {
        super(CustomerType.RETURNING);
    }

    @Override
    public void doSubjectLine() {
        System.out.println("Welcome Back!");
    }

    @Override
    public void doMessage() {
        System.out.println("It has been a while since you last logged in.");
        System.out.println("Make sure to checkout our recent newsletter for up-to-date information on new rubber ducks in stock!");
    }
}
