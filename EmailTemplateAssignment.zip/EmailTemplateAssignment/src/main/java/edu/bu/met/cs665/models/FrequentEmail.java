/**
 * Name: Pranjal Prasanna Ekhande
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: FrequentEmail.java
 * Description: Overrides CustomerEmail to crafting Recurring emails of sales.
 */


package edu.bu.met.cs665.models;

public class FrequentEmail extends CustomerEmail{

    public FrequentEmail() {
        super(CustomerType.FREQUENT);
    }

    @Override
    public void doSubjectLine() {
        System.out.println("Special Offer!!!");
    }

    @Override
    public void doMessage() {
        System.out.println("Hope you are having a lovely day! :)");
    }
}
