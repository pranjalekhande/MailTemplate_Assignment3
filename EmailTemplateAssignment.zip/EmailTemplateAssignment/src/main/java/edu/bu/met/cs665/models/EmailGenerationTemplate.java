/**
 * Name: Pranjal Prasanna Ekhande
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: EmailGenerationTemplate.java
 * Description: Employs the template method pattern, offering abstract methods for generating emails.
 */


package edu.bu.met.cs665.models;

public abstract class EmailGenerationTemplate {

    public boolean isBusiness;
    public boolean isReturning;
    public boolean isFrequent;
    public boolean isNew;
    public boolean isVip;

    /**
     * Works as template method, runs all methods to generate email.
     * @param recipientName name of email recipient
     * @param senderName name of email sender
     */
    public final void generateEmail(String recipientName, String senderName) {
        // Generates header of email.
        doHeader();
        // Generates subject line of email.
        doSubjectLine();
        // Generates greeting of email.
        doGreeting(recipientName);
        doMessage();
        if (isFrequent || isVip) {
            doPromotion();
        }
        doSignature(senderName);
    }

    public void doHeader() {
        System.out.println("The Nike Shoes Shop - Personalized Shoes ALL!");
    }

    public abstract void doSubjectLine();

    public void doGreeting(String recipientName) {
        System.out.println("Greetings " + recipientName + ",");
    }

    public abstract void doMessage();

    public void doPromotion() {
        System.out.println("Thank you for being a loyal customer!");
        System.out.println("For a limited time save 40% your account renewal with promo code: ");
        System.out.println("SHOE2023NX");
    }

    public void doSignature(String senderName) {
        System.out.println("Sincerely,");
        System.out.println(senderName);
        System.out.println("Team Member @ The Nike Corporation");
    }
}
