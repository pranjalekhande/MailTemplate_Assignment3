

/**
 * Name: Pranjal Prasanna Ekhande
 * Course: CS-665 Software Designs & Patterns
 * Date: 03/07/2024
 * File Name: Main.java
 * Description: This class used for running the application
 */

package edu.bu.met.cs665;

import edu.bu.met.cs665.example1.Person;

import edu.bu.met.cs665.models.BusinessEmail;
import edu.bu.met.cs665.models.FrequentEmail;
import edu.bu.met.cs665.models.NewEmail;
import edu.bu.met.cs665.models.ReturningEmail;
import edu.bu.met.cs665.models.VipEmail;
/**
 * This is the Main class.
 */
public class Main {

  /**
   * A main method to run examples.
   * You may use this method for development purposes as you start building your
   * assignments/final project.  This could prove convenient to test as you are developing.
   * However, please note that every assignment/final projects requires JUnit tests.
   */
  public static void main(String[] args) {
    // Testing all emails. Should all print to console.
    BusinessEmail businessEmail = new BusinessEmail();
    FrequentEmail freqEmail = new FrequentEmail();
    ReturningEmail returningEmail = new ReturningEmail();
    NewEmail newEmail = new NewEmail();
    VipEmail vipEmail = new VipEmail();

    System.out.println("BUSINESS EMAIL:\n");
    businessEmail.generateEmail("Henry", "Toby");
    System.out.println();

    System.out.println("FREQUENT EMAIL:\n");
    freqEmail.generateEmail("Samantha", "Julie");
    System.out.println();

    System.out.println("RETURNING EMAIL:\n");
    returningEmail.generateEmail("Christopher", "John");
    System.out.println();

    System.out.println("NEW EMAIL:\n");
    newEmail.generateEmail("Clydee", "Izzy");
    System.out.println();

    System.out.println("VIP EMAIL:\n");
    vipEmail.generateEmail("Nick", "Thomas");
    System.out.println();
  }


}
